package com.mini.Library.Options;

import javax.sql.DataSource;

public interface optionsDAO{
	public void setDataSource(DataSource ds);
	public Boolean checkStatus(String option_id);
	public Boolean toggleStatus(String option_id);
}