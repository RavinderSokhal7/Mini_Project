package com.mini.Library;

public class Link{
	private String link;
	private String name;
	public Link(String link,String name) { this.link = link; this.name = name; }
	public String getLink() { return this.link; }
	public String getName() { return this.name; }
}