package com.mini.Library;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
public class MenuLinks {
	private List<Link> adminLinks;
	private List<Link> userLinks;
	private List<Link> guestLinks;
	public MenuLinks() {
		adminLinks = new ArrayList<>();
		this.adminLinks.add(new Link("logout","Logout"));
		this.adminLinks.add(new Link("issue-return","Issue/Return"));
		this.adminLinks.add(new Link("books","Books"));
		this.adminLinks.add(new Link("dashboard","Dashboard"));

		userLinks = new ArrayList<>();
		this.userLinks.add(new Link("logout","Logout"));
		this.userLinks.add(new Link("dashboard","Dashboard"));
		this.userLinks.add(new Link("update_details","Update Details"));
		this.userLinks.add(new Link("books","Books"));
		this.userLinks.add(new Link("contacts","Contacts"));

		guestLinks = new ArrayList<>();
		this.guestLinks.add(new Link("login","Login"));
		this.guestLinks.add(new Link("register","Register"));
		this.guestLinks.add(new Link("books","Books"));
		this.guestLinks.add(new Link("contacts","Contacts"));
	}
	public List<Link> getLinks(HttpServletRequest request){
		if(request.getSession().getAttribute("user") != null) {
			String usertype = (String)request.getSession().getAttribute("usertype");
			if(usertype.matches("admin")) { return adminLinks; }
			else { return userLinks; }
		}
		return guestLinks;
	}
}