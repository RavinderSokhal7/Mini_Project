package com.mini.Library.Options;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class optionsMapper implements RowMapper<options> {
   public options mapRow(ResultSet rs, int rowNum) throws SQLException {
	  int status = rs.getInt("option_status");
	  Boolean stats = true;
	  if(status == 1) { stats = true;} else { stats = false;}
      options opt = new options();
      opt.setID(rs.getString("options_id"));
      opt.setName(rs.getString("option_name"));
      opt.setDetails(rs.getString("option_details"));
      opt.setStatus(stats);
      return opt;
   }
}