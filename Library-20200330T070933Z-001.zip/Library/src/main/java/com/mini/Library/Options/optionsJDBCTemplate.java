package com.mini.Library.Options;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class optionsJDBCTemplate implements optionsDAO{
	private JdbcTemplate jdbcTemplateObject;
	
	public void setDataSource(DataSource dataSource) {
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public Boolean checkStatus(String option_id) {
		String SQL = "SELECT * from options where options_id = ?";
		options opt = jdbcTemplateObject.queryForObject(SQL, new Object[] {option_id}, new optionsMapper());
		return opt.getStatus();
	}

	public Boolean toggleStatus(String option_id) {
		String SQL = "";
		if(checkStatus(option_id)) { SQL = "UPDATE options set option_status = 0 where option_id = ?"; }
		else { SQL = "UPDATE options set option_status = 1 where option_id = ?"; }
		jdbcTemplateObject.queryForObject(SQL, new Object[] {option_id}, new optionsMapper());
		return true;
	}
	
}