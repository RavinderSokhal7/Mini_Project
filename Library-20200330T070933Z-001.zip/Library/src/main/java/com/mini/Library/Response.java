package com.mini.Library;

public class Response{
	public boolean status;
	public String message;
	public Response(boolean status, String message) {
		this.status = status;
		this.message = message;
	}
}