package com.mini.Library;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
public class QuickLinks {
	List<Link> adminLinks;
	List<Link> userLinks;
	List<Link> guestLinks;
	public QuickLinks() {
		adminLinks = new ArrayList<>();
		adminLinks.add(new Link("logout","Logout"));
		adminLinks.add(new Link("issue-return","Issue/Return"));
		adminLinks.add(new Link("view_details","View Details"));
		adminLinks.add(new Link("update_details","Update Details"));
		
		userLinks = new ArrayList<>();
		userLinks.add(new Link("logout","Logout"));
		userLinks.add(new Link("dashboard","Dashboard"));
		userLinks.add(new Link("update_details","Update Details"));

		guestLinks = new ArrayList<>();
		guestLinks.add(new Link("login","Login"));
		guestLinks.add(new Link("register","Register"));
	}
	public List<Link> getLinks(HttpServletRequest request){
		if(request.getSession().getAttribute("user") != null) {
			String usertype = (String)request.getSession().getAttribute("usertype");
			if(usertype.matches("admin")) { return adminLinks; }
			else { return userLinks; }
		}
		return guestLinks;
	}
}