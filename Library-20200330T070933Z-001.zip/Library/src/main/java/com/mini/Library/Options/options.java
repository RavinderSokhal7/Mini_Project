package com.mini.Library.Options;

public class options{
	private String option_id;
	private String option_name;
	private String option_details;
	private Boolean status;
	public void setID(String option_id) { this.option_id = option_id; }
	public void setName(String option_name) { this.option_name = option_name; }
	public void setDetails(String option_details) { this.option_details = option_details; }
	public void setStatus(Boolean status) { this.status = status; }
	public String getID() { return this.option_id; }
	public String getName() { return this.option_name; }
	public String getDetails() { return this.option_details; }
	public Boolean getStatus() { return this.status; }
}